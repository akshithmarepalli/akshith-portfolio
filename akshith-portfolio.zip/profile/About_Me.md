# About Me
I am an AI & DS undergraduate passionate about ML, VR development, and data-driven applications.