# VR Tourism Project Completion Certificate

Recognized for development of VR tourism platform.