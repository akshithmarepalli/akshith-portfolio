# Swecha – Summer of AI Internship Certificate (2024)

Participated in AI-driven cultural and language preservation projects.