# Marepalli Akshith

Aspiring AI & Data Science Engineer | VR Developer | ML Enthusiast

## Skills
Python, Java, C  
TensorFlow, Keras, Pandas, Matplotlib, GitHub, Ubuntu  
A‑Frame, Three.js, Babylon.js, HTML, CSS, JS

## Projects
### Web-Based Virtual Reality Tourism Project
360° VR tourism platform using A‑Frame, Three.js, Babylon.js.

## Internships
- Summer of AI Internship – SWECHA (2024)

## Certificates
- SWECHA AI Internship Certificate
- VR Tourism Project Certificate

## Contact
Email: akshith.marepalli@gmail.com  
LinkedIn: linkedin.com/in/akshith-marepalli  
GitHub: github.com/akshithmarepalli
